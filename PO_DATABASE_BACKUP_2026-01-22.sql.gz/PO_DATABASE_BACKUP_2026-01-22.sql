-- MariaDB dump 10.19  Distrib 10.11.14-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	10.11.14-MariaDB-ubu2204-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `loan_guarantors`
--

DROP TABLE IF EXISTS `loan_guarantors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `loan_guarantors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `loan_id` int(11) NOT NULL,
  `guarantor_id` int(11) NOT NULL,
  `status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `responded_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `loan_guarantor_unique` (`loan_id`,`guarantor_id`),
  KEY `guarantor_id` (`guarantor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loan_guarantors`
--

LOCK TABLES `loan_guarantors` WRITE;
/*!40000 ALTER TABLE `loan_guarantors` DISABLE KEYS */;
/*!40000 ALTER TABLE `loan_guarantors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `loan_payments`
--

DROP TABLE IF EXISTS `loan_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `loan_payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `loan_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `paid_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `loan_id` (`loan_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loan_payments`
--

LOCK TABLES `loan_payments` WRITE;
/*!40000 ALTER TABLE `loan_payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `loan_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `loans`
--

DROP TABLE IF EXISTS `loans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `loans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `balance` decimal(10,2) NOT NULL,
  `interest_rate` decimal(4,2) NOT NULL DEFAULT 2.00,
  `status` varchar(255) NOT NULL DEFAULT 'pending',
  `requested_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `approved_at` timestamp NULL DEFAULT NULL,
  `approved_by_user_id` int(11) DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `last_interest_applied_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `approved_by_user_id` (`approved_by_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loans`
--

LOCK TABLES `loans` WRITE;
/*!40000 ALTER TABLE `loans` DISABLE KEYS */;
/*!40000 ALTER TABLE `loans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logs`
--

DROP TABLE IF EXISTS `logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `action` text DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logs`
--

LOCK TABLES `logs` WRITE;
/*!40000 ALTER TABLE `logs` DISABLE KEYS */;
INSERT INTO `logs` VALUES
(1,2,'Created new user: nuwapeter2013 (ID: 3)','2026-01-22 07:21:28'),
(2,2,'Created new user: osbert.austin (ID: 4)','2026-01-22 07:22:36'),
(3,2,'Created new user: alex.tumwiine (ID: 5)','2026-01-22 07:23:41'),
(4,2,'Created new user: micheal.kabwekyere (ID: 6)','2026-01-22 09:39:09'),
(5,2,'Created new user: emma.wa (ID: 7)','2026-01-22 09:40:39'),
(6,2,'Created new user: salimu.asasira (ID: 8)','2026-01-22 09:42:37'),
(7,2,'Created new user: christine.arinaitwe (ID: 9)','2026-01-22 09:43:41'),
(8,2,'Created new user: agaba.john (ID: 10)','2026-01-22 09:45:45'),
(9,3,'Added a saving of 30000 for user ID 10.','2026-01-22 12:02:51'),
(10,3,'Added a saving of 10000 for user ID 5.','2026-01-22 12:03:10'),
(11,3,'Added a saving of 10000 for user ID 9.','2026-01-22 12:03:42'),
(12,3,'Added a saving of 20000 for user ID 7.','2026-01-22 12:05:43'),
(13,3,'Added a saving of 120000 for user ID 6.','2026-01-22 12:06:05'),
(14,3,'Added a saving of 260000 for user ID 3.','2026-01-22 12:06:30'),
(15,3,'Added a saving of 30000 for user ID 4.','2026-01-22 12:06:58'),
(16,3,'Added a saving of 20000 for user ID 8.','2026-01-22 12:07:15'),
(17,3,'Updated profile for user: emma.wa (ID: 7)','2026-01-22 12:11:33'),
(18,3,'Created new user: catherine.natamba (ID: 11)','2026-01-22 20:08:28');
/*!40000 ALTER TABLE `logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` VALUES
(1,10,'Your account has been credited with $30,000.00',0,'2026-01-22 12:02:51'),
(2,5,'Your account has been credited with $10,000.00',0,'2026-01-22 12:03:10'),
(3,9,'Your account has been credited with $10,000.00',0,'2026-01-22 12:03:42'),
(4,7,'Your account has been credited with $20,000.00',0,'2026-01-22 12:05:43'),
(5,6,'Your account has been credited with $120,000.00',0,'2026-01-22 12:06:05'),
(6,3,'Your account has been credited with $260,000.00',1,'2026-01-22 12:06:30'),
(7,4,'Your account has been credited with $30,000.00',0,'2026-01-22 12:06:58'),
(8,8,'Your account has been credited with $20,000.00',0,'2026-01-22 12:07:15');
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_resets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `token` varchar(255) NOT NULL,
  `expires_at` datetime NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `password_resets_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `savings`
--

DROP TABLE IF EXISTS `savings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `savings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `amount` decimal(10,2) DEFAULT NULL,
  `proof_image_path` varchar(255) DEFAULT NULL,
  `verified_by_user_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `savings`
--

LOCK TABLES `savings` WRITE;
/*!40000 ALTER TABLE `savings` DISABLE KEYS */;
INSERT INTO `savings` VALUES
(1,10,30000.00,'uploads/proofs/697211ebcc1c3-poa_dark.png',3,'2026-01-22 12:02:51'),
(2,5,10000.00,'uploads/proofs/697211fe9248f-poa_dark.png',3,'2026-01-22 12:03:10'),
(3,9,10000.00,'uploads/proofs/6972121e8876c-poa_dark.png',3,'2026-01-22 12:03:42'),
(4,7,20000.00,'uploads/proofs/697212978a58a-poa_dark.png',3,'2026-01-22 12:05:43'),
(5,6,120000.00,'uploads/proofs/697212adc1b22-poa_light.png',3,'2026-01-22 12:06:05'),
(6,3,260000.00,'uploads/proofs/697212c666ea8-poa_light.png',3,'2026-01-22 12:06:30'),
(7,4,30000.00,'uploads/proofs/697212e2b0aef-poa_light.png',3,'2026-01-22 12:06:58'),
(8,8,20000.00,'uploads/proofs/697212f3c772d-poa_light.png',3,'2026-01-22 12:07:15');
/*!40000 ALTER TABLE `savings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_settings`
--

DROP TABLE IF EXISTS `system_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(255) NOT NULL,
  `setting_value` text DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `setting_key` (`setting_key`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_settings`
--

LOCK TABLES `system_settings` WRITE;
/*!40000 ALTER TABLE `system_settings` DISABLE KEYS */;
INSERT INTO `system_settings` VALUES
(1,'last_interest_run','2026-01-22 09:31:05','2026-01-22 06:31:05');
/*!40000 ALTER TABLE `system_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_no` varchar(255) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `surname` varchar(100) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `role_id` int(11) DEFAULT NULL,
  `avatar` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `account_no` (`account_no`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,'POA00000','Root','User','root','root@poa.dev','0','$2y$10$CQoZZXkbiWu6/s9vUgBB7OtQuf0JuSOOSYuwsuQDuHSxd1YQy4wbi',1,'assets/uploads/avatars/avatar_6971c449d0eb27.82675202.png','2026-01-22 06:29:16'),
(2,'POA00001','Chairman','Admin','chairman','chairman@poa.dev','1','$2y$10$CQoZZXkbiWu6/s9vUgBB7OtQuf0JuSOOSYuwsuQDuHSxd1YQy4wbi',2,NULL,'2026-01-22 06:29:16'),
(3,'POA00002','Peter','Nuwahereza','nuwapeter2013','nuwapeter2013@gmail.com','0703985940','$2y$10$K28r5oMpeSrCIExvnZdhwuMKRscUQFsMPLG7ANNr06ijk9s7GSQiy',2,NULL,'2026-01-22 07:21:28'),
(4,'POA00003','Osbert','Akandwanaho','osbert.austin','osbertakandwanaho746@gmail.com','0742765580','$2y$10$oMtLQvqXv3u9LAuPFwOP2u64uoa9cdqpA1taQ.7McAmwQH.rlU02C',5,NULL,'2026-01-22 07:22:36'),
(5,'POA00004','Alex','Twinomugisha','alex.tumwiine','alextumwiine83@gmail.com','0761320037','$2y$10$xCPP/2ukJgtvLqgMXlDmrevM7iGoteKTYs6K8MFUu34CkdFZ/C7bu',5,NULL,'2026-01-22 07:23:41'),
(6,'POA00005','Micheal','Kabwekyere','micheal.kabwekyere','michealkabwekyere@gmail.com','0392300381','$2y$10$MTa6oOweq4iJwEnGeUNGe.gXF6DwBXLHiNXeYY0zfO2qCRVU05pP6',4,NULL,'2026-01-22 09:39:09'),
(7,'POA00006','Emmanuel','Turyakyira','emma.wa','emmanuelturyax@gmail.com','0755502553','$2y$10$JF9fRDe7./Is8g34q.xL.ed6Ap9oYv5XL2OXi09nxZpwYamrb52EK',5,NULL,'2026-01-22 09:40:39'),
(8,'POA00007','Salimu','Asasira','salimu.asasira','asasirasalimu233@gmail.com','0759557614','$2y$10$LEVLs3vwa5mGP9SjRmHODOXAyZkeSj6OfRLsq2Mm4Jgy0//K68Ng2',5,NULL,'2026-01-22 09:42:37'),
(9,'POA00008','Christine','Arinaitwe','christine.arinaitwe','chris@one.com','0755389397','$2y$10$cZwbuv9kQeFzWqmYCjlhVehgA162lAGs7WrreLsYEmPV7P7hd4WdC',5,NULL,'2026-01-22 09:43:41'),
(10,'POA00009','John Chrysostom','Agaba','agaba.john','agabajohnchrysostom78@gmail.com','0787785468','$2y$10$tQ2a4Hp6.lkrWpfYUjGpa./yvWTu8JScdGrJ87eOKZ88cWh49emn.',5,NULL,'2026-01-22 09:45:45'),
(11,'POA00010','Catherine','Natamba','catherine.natamba','cathykayz594@gmail.com','0742808608','$2y$10$JRQDuLoG04wOsCJttY7Wu.wuLJhnFJmnfw0Gtf2zML6I.aBUv5o3W',5,'assets/uploads/avatars/avatar_697284c915c522.14172626.jpg','2026-01-22 20:08:28');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `withdrawals`
--

DROP TABLE IF EXISTS `withdrawals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `withdrawals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'pending',
  `requested_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `processed_at` timestamp NULL DEFAULT NULL,
  `processed_by_user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `processed_by_user_id` (`processed_by_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `withdrawals`
--

LOCK TABLES `withdrawals` WRITE;
/*!40000 ALTER TABLE `withdrawals` DISABLE KEYS */;
/*!40000 ALTER TABLE `withdrawals` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-01-22 23:25:16
